package com.assignment.recruitment.candidate;





import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.recruitment.database.DatabaseClass;
import com.assignment.recruitment.offer.OfferService;

@RestController
public class CanditateController {
	
	@Autowired
	private OfferService offerservice;

 
  
  @RequestMapping(value="/applyjob",method = RequestMethod.POST) 
  public String addOffer(HttpServletRequest request) { 
	 
	  return DatabaseClass.applyJob(request.getParameter("email"),request.getParameter("resumetxt"),request.getParameter("offer"));
	  }
  
 
}
