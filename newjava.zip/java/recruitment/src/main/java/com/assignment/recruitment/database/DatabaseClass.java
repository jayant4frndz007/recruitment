package com.assignment.recruitment.database;

import java.util.HashMap;
import java.util.Map;

import com.assignment.recruitment.candidate.Candidate;
import com.assignment.recruitment.offer.Application;
import com.assignment.recruitment.offer.Offer;

public class DatabaseClass {

	private static Map<Integer,Offer> offers = new HashMap<>();
	private static Map<String,Candidate> applications = new HashMap<>();
	
	static{
		offers.put(1,new Offer("Java Developer","2020-07-21",1));
	    offers.put(2,new Offer("App Tester","2020-07-15",1));
	}   
	public static Map<Integer, Offer> getOffers(){
		return offers;
	}
	public static Map<String, Candidate> getDetails(){
		return applications;
	}
	
	public static String addOffer(String sub, String date,int vac) {
		offers.put(offers.size()+1,new Offer(sub,date,vac));
		return "success";
	}
	public static String applyJob(String email, String resumetext,String relateOffer) {
		applications.put(email,new Candidate(email,relateOffer,resumetext,"Applied"));
		return "Applied";
	}
}
