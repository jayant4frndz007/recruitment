package com.assignment.recruitment.candidate;

public class ApplyJob {

}
