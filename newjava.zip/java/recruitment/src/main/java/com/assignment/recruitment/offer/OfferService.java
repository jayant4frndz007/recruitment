package com.assignment.recruitment.offer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.HashMap;

import org.springframework.stereotype.Service;

import com.assignment.recruitment.candidate.Candidate;
import com.assignment.recruitment.database.DatabaseClass;

@Service
public class OfferService {
	
	private Map<Integer, Offer> offers = DatabaseClass.getOffers();
	private Map<String, Candidate> cand = DatabaseClass.getDetails();
	
			
    public List<Offer> getAllOffers(){
		ArrayList<Offer> alloffers = new ArrayList<>(offers.values());
		return alloffers;
			
    }
    public List<Candidate> getAllDetails(){
		ArrayList<Candidate> alloffers = new ArrayList<>(cand.values());
		System.out.println(alloffers);
		return alloffers;
			
    }
    public Candidate getDetails(String email){
		
		
		return cand.get(email);
			
    }
	
	 public Offer getOffer(String id) {
		return null;
       
	 }
	 
	  public void addOffer(Offer offer) { 
		  }
	  }
	 

