package com.assignment.recruitment.offer;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.recruitment.candidate.Candidate;
import com.assignment.recruitment.database.DatabaseClass;

@RestController
public class OfferController {
	
	@Autowired
	private OfferService offerservice;

 @RequestMapping("/offers")
 public List<Offer> getAllOffers(){
	System.out.print(offerservice.getAllOffers());	
	return offerservice.getAllOffers();
 }

  @RequestMapping("/offers/{id}") 
  public Offer getOffer(@PathVariable String id){ 
	  return offerservice.getOffer(id); }


  @RequestMapping("/getDetails") 
  public List<Candidate> getAllDetails(){ 
	  return  offerservice.getAllDetails(); 
	  }
  
  @RequestMapping("/getDetails/{id}") 
  public Candidate getDetails(@PathVariable String id){ 
	  return offerservice.getDetails(id); 
	  }
  
  @RequestMapping(value="/addoffers",method = RequestMethod.POST) 
  public String addOffer(HttpServletRequest request) { 
	 
	  return DatabaseClass.addOffer(request.getParameter("subject"), request.getParameter("date"), Integer.parseInt(request.getParameter("vacancy")));
	  }
  
 
}