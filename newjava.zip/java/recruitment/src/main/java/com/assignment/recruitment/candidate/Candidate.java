package com.assignment.recruitment.candidate;

public class Candidate {


	  private String relateOffer; 
	  private String email;
	  private String resumetext; 
	  private String applStatus;
	  
	  public String getRelateOffer() {
		return relateOffer;
	}

	public void setRelateOffer(String relateOffer) {
		this.relateOffer = relateOffer;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getResumetext() {
		return resumetext;
	}

	public void setResumetext(String resumetext) {
		this.resumetext = resumetext;
	}

	public String getApplStatus() {
		return applStatus;
	}

	public void setApplStatus(String applStatus) {
		this.applStatus = applStatus;
	}

	public Candidate(String email,String relateOffer, String resumetext, String applStatus) {
			super();
			this.email=email;
			this.relateOffer = relateOffer;
			this.resumetext = resumetext;
			this.applStatus = applStatus;
		}
	  
	  
}
